Work (C) 2014 Mike Brent Harmlesslion.com
All rights reserved.

Free for personal use! Enjoy! Contact before derived works.
